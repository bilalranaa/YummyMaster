package com.example.yummypoint.Common;

import com.example.yummypoint.Model.User;

public class Common {
    public static User currentUser;
}
